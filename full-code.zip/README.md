laravel-and-parse-book
======================

this is the code for jasmine web app book, which talk about using laravel 4 with parse.com
