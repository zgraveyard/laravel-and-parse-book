<?php
return array(
    'perPage' => 10,
    'homePerPage' => 2
);