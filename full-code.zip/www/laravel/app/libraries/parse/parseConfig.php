<?php

class parseConfig {
    const APPID = 'D8s479IYdHR6uSFBYXsedjPANYNk8tZvfeOkji50';
    const MASTERKEY = '4sFcF2UV9126M9x1X5Jh5px6NvmZHSqdTDMVNuki';
    const RESTKEY = 'zCTQp4h2wLrjahIUVERkTsEi2156hKlHtCfYOE5P';
    const PARSEURL = 'https://api.parse.com/1/';
}